package JDBC;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PartC {

    // ===== Model =====
    static class Student {
        int studentID;
        String name;
        String department;
        int marks;

        Student(int studentID, String name, String department, int marks) {
            this.studentID = studentID;
            this.name = name;
            this.department = department;
            this.marks = marks;
        }
    }

    // ===== Controller =====
    static class StudentDAO {
        private Connection con;

        StudentDAO(Connection con) { this.con = con; }

        void addStudent(Student s) throws SQLException {
            String sql = "INSERT INTO Student (StudentID, Name, Department, Marks) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, s.studentID);
                ps.setString(2, s.name);
                ps.setString(3, s.department);
                ps.setInt(4, s.marks);
                ps.executeUpdate();
            }
        }

        List<Student> getAllStudents() throws SQLException {
            List<Student> list = new ArrayList<>();
            String sql = "SELECT * FROM Student";
            try (Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    list.add(new Student(
                            rs.getInt("StudentID"),
                            rs.getString("Name"),
                            rs.getString("Department"),
                            rs.getInt("Marks")
                    ));
                }
            }
            return list;
        }

        void updateStudent(Student s) throws SQLException {
            String sql = "UPDATE Student SET Name=?, Department=?, Marks=? WHERE StudentID=?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, s.name);
                ps.setString(2, s.department);
                ps.setInt(3, s.marks);
                ps.setInt(4, s.studentID);
                ps.executeUpdate();
            }
        }

        void deleteStudent(int studentID) throws SQLException {
            String sql = "DELETE FROM Student WHERE StudentID=?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, studentID);
                ps.executeUpdate();
            }
        }
    }

    // ===== View + Main =====
    public static void main(String[] args) {
        final String URL = "jdbc:mysql://bytexldb.com:5051/db_43yzfksca";
        final String USER = "user_43yzfksca";
        final String PASS = "p43yzfksca";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             Scanner sc = new Scanner(System.in)) {

            StudentDAO dao = new StudentDAO(con);

            while (true) {
                System.out.println("\n--- Student Management Menu ---");
                System.out.println("1. Add Student");
                System.out.println("2. View Students");
                System.out.println("3. Update Student");
                System.out.println("4. Delete Student");
                System.out.println("5. Exit");
                System.out.print("Choose option: ");
                int choice = sc.nextInt();
                sc.nextLine(); // consume newline

                switch (choice) {
                    case 1 -> {
                        System.out.print("Enter StudentID: "); int id = sc.nextInt(); sc.nextLine();
                        System.out.print("Enter Name: "); String name = sc.nextLine();
                        System.out.print("Enter Department: "); String dept = sc.nextLine();
                        System.out.print("Enter Marks: "); int marks = sc.nextInt();
                        dao.addStudent(new Student(id, name, dept, marks));
                        System.out.println("Student added successfully.");
                    }
                    case 2 -> {
                        List<Student> students = dao.getAllStudents();
                        System.out.println("ID\tName\tDepartment\tMarks");
                        for (Student s : students) {
                            System.out.printf("%d\t%s\t%s\t%d\n",
                                    s.studentID, s.name, s.department, s.marks);
                        }
                    }
                    case 3 -> {
                        System.out.print("Enter StudentID to update: "); int id = sc.nextInt(); sc.nextLine();
                        System.out.print("Enter Name: "); String name = sc.nextLine();
                        System.out.print("Enter Department: "); String dept = sc.nextLine();
                        System.out.print("Enter Marks: "); int marks = sc.nextInt();
                        dao.updateStudent(new Student(id, name, dept, marks));
                        System.out.println("Student updated successfully.");
                    }
                    case 4 -> {
                        System.out.print("Enter StudentID to delete: "); int id = sc.nextInt();
                        dao.deleteStudent(id);
                        System.out.println("Student deleted successfully.");
                    }
                    case 5 -> { System.out.println("Exiting..."); return; }
                    default -> System.out.println("Invalid choice!");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}