
package JDBC;
import java.sql.*;
import java.util.Scanner;

public class PartB {
    static final String URL = "jdbc:mysql://bytexldb.com:5051/db_43yzfksca";
    static final String USER = "user_43yzfksca";
    static final String PASS = "p43yzfksca";

    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             Scanner sc = new Scanner(System.in)) {

            con.setAutoCommit(false); // Enable transaction handling

            while (true) {
                System.out.println("\nProduct CRUD Menu:");
                System.out.println("1. Create Product");
                System.out.println("2. Read Products");
                System.out.println("3. Update Product");
                System.out.println("4. Delete Product");
                System.out.println("5. Exit");
                System.out.print("Choose option: ");
                int choice = sc.nextInt();

                switch (choice) {
                    case 1 -> createProduct(con, sc);
                    case 2 -> readProducts(con);
                    case 3 -> updateProduct(con, sc);
                    case 4 -> deleteProduct(con, sc);
                    case 5 -> {
                        con.close();
                        return;
                    }
                    default -> System.out.println("Invalid choice!");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createProduct(Connection con, Scanner sc) {
        try {
            System.out.print("Enter ProductID: ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter ProductName: ");
            String name = sc.nextLine();
            System.out.print("Enter Price: ");
            double price = sc.nextDouble();
            System.out.print("Enter Quantity: ");
            int qty = sc.nextInt();

            String sql = "INSERT INTO Product (ProductID, ProductName, Price, Quantity) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, id);
                ps.setString(2, name);
                ps.setDouble(3, price);
                ps.setInt(4, qty);
                ps.executeUpdate();
                con.commit();
                System.out.println("Product created successfully.");
            }
        } catch (SQLException e) {
            try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            System.out.println("Error creating product: " + e.getMessage());
        }
    }

    private static void readProducts(Connection con) {
        String sql = "SELECT * FROM Product";
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            System.out.println("ProductID\tName\tPrice\tQuantity");
            while (rs.next()) {
                System.out.printf("%d\t%s\t%.2f\t%d\n",
                        rs.getInt("ProductID"),
                        rs.getString("ProductName"),
                        rs.getDouble("Price"),
                        rs.getInt("Quantity"));
            }
        } catch (SQLException e) {
            System.out.println("Error reading products: " + e.getMessage());
        }
    }

    private static void updateProduct(Connection con, Scanner sc) {
        try {
            System.out.print("Enter ProductID to update: ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter new ProductName: ");
            String name = sc.nextLine();
            System.out.print("Enter new Price: ");
            double price = sc.nextDouble();
            System.out.print("Enter new Quantity: ");
            int qty = sc.nextInt();

            String sql = "UPDATE Product SET ProductName=?, Price=?, Quantity=? WHERE ProductID=?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, name);
                ps.setDouble(2, price);
                ps.setInt(3, qty);
                ps.setInt(4, id);

                int rows = ps.executeUpdate();
                if (rows > 0) {
                    con.commit();
                    System.out.println("Product updated successfully.");
                } else {
                    System.out.println("ProductID not found.");
                }
            }
        } catch (SQLException e) {
            try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            System.out.println("Error updating product: " + e.getMessage());
        }
    }

    private static void deleteProduct(Connection con, Scanner sc) {
        try {
            System.out.print("Enter ProductID to delete: ");
            int id = sc.nextInt();

            String sql = "DELETE FROM Product WHERE ProductID=?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, id);
                int rows = ps.executeUpdate();
                if (rows > 0) {
                    con.commit();
                    System.out.println("Product deleted successfully.");
                } else {
                    System.out.println("ProductID not found.");
                }
            }
        } catch (SQLException e) {
            try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            System.out.println("Error deleting product: " + e.getMessage());
        }
    }
}